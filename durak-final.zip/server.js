const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const bcrypt = require('bcryptjs');
const fs = require('fs');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' }, maxHttpBufferSize: 1e8 });

app.use(express.json({ limit: '50mb' }));
app.use(express.static(__dirname));

// ─── DATABASE ────────────────────────────────────────────────
const DB = './db.json';

function load() {
  if (!fs.existsSync(DB)) return { users: {}, chats: {}, groups: {} };
  try { return JSON.parse(fs.readFileSync(DB, 'utf8')); }
  catch { return { users: {}, chats: {}, groups: {} }; }
}

function save() {
  try { fs.writeFileSync(DB, JSON.stringify(db)); }
  catch (e) { console.error('DB save error:', e.message); }
}

let db = load();
if (!db.chats) db.chats = {};
if (!db.groups) db.groups = {};

// Владелец
(async () => {
  if (!db.users['MrDarvi']) {
    db.users['MrDarvi'] = {
      username: 'MrDarvi',
      password: await bcrypt.hash('Reallymcdragonminedarviyt4459', 10),
      emoji: '👑', photo: null,
      balance: 999999, wins: 0, games: 0,
      lastSpin: 0, boosts: { skip: 99, view: 99, shield: 99 },
      friends: [], requests: [], notifs: [],
      banned: false, banUntil: null, owner: true
    };
    save();
    console.log('Owner MrDarvi created');
  }
})();

function pub(u) {
  return {
    username: u.username, emoji: u.emoji, photo: u.photo || null,
    balance: u.balance, wins: u.wins, games: u.games,
    lastSpin: u.lastSpin || 0, boosts: u.boosts || {},
    friends: u.friends || [], notifs: u.notifs || [],
    owner: u.owner || false
  };
}

// ─── AUTH ────────────────────────────────────────────────────
app.post('/api/register', async (req, res) => {
  try {
    const { username, password, emoji, photo } = req.body;
    if (!username || !password) return res.json({ ok: false, err: 'Заполните все поля' });
    if (username.length < 2 || username.length > 16) return res.json({ ok: false, err: 'Ник 2–16 символов' });
    if (password.length < 4) return res.json({ ok: false, err: 'Пароль минимум 4 символа' });
    if (db.users[username]) return res.json({ ok: false, err: 'Пользователь уже существует' });
    db.users[username] = {
      username, password: await bcrypt.hash(password, 10),
      emoji: emoji || '🎭', photo: photo || null,
      balance: 1000, wins: 0, games: 0, lastSpin: 0,
      boosts: { skip: 0, view: 0, shield: 0 },
      friends: [], requests: [], notifs: [],
      banned: false, banUntil: null, owner: false
    };
    save();
    res.json({ ok: true, user: pub(db.users[username]) });
  } catch (e) {
    res.json({ ok: false, err: 'Ошибка сервера: ' + e.message });
  }
});

app.post('/api/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    const u = db.users[username];
    if (!u) return res.json({ ok: false, err: 'Пользователь не найден' });
    if (!await bcrypt.compare(password, u.password)) return res.json({ ok: false, err: 'Неверный пароль' });
    if (u.banned) {
      if (u.banUntil && Date.now() > u.banUntil) { u.banned = false; u.banUntil = null; save(); }
      else return res.json({ ok: false, err: u.banUntil ? `Бан до ${new Date(u.banUntil).toLocaleString('ru')}` : 'Вы заблокированы' });
    }
    res.json({ ok: true, user: pub(u) });
  } catch (e) {
    res.json({ ok: false, err: 'Ошибка сервера' });
  }
});

app.post('/api/profile', async (req, res) => {
  try {
    const { username, emoji, photo } = req.body;
    const u = db.users[username];
    if (!u) return res.json({ ok: false, err: 'Не найден' });
    if (emoji) u.emoji = emoji;
    if (photo !== undefined) u.photo = photo;
    save();
    res.json({ ok: true, user: pub(u) });
  } catch (e) {
    res.json({ ok: false, err: 'Ошибка' });
  }
});

app.get('/api/leaderboard', (req, res) => {
  const list = Object.values(db.users)
    .map(u => ({ username: u.username, emoji: u.emoji, photo: u.photo, balance: u.balance, wins: u.wins, games: u.games }))
    .sort((a, b) => b.balance - a.balance || b.wins - a.wins)
    .slice(0, 30);
  res.json(list);
});

// ─── CARDS ───────────────────────────────────────────────────
const SUITS = ['♠', '♥', '♦', '♣'];
const RANKS = ['6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A'];
const RANK_VAL = { '6': 6, '7': 7, '8': 8, '9': 9, '10': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14 };

function makeDeck() {
  const d = [];
  for (const s of SUITS) for (const r of RANKS) d.push({ s, r });
  for (let i = d.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [d[i], d[j]] = [d[j], d[i]];
  }
  return d;
}

function beats(atk, def, trump) {
  if (atk.s === def.s) return RANK_VAL[def.r] > RANK_VAL[atk.r];
  return def.s === trump;
}

function cardEq(a, b) { return a.s === b.s && a.r === b.r; }

// ─── GAME STATE ──────────────────────────────────────────────
const rooms = {}; // code -> room
const online = {}; // socket.id -> username
const userSock = {}; // username -> socket.id

function genCode() {
  const C = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  return Array.from({ length: 5 }, () => C[Math.floor(Math.random() * C.length)]).join('');
}

function startGame(code) {
  const room = rooms[code];
  const deck = makeDeck();
  const trump = deck[deck.length - 1].s;
  const trumpCard = deck[deck.length - 1];
  const hands = {};
  for (const p of room.players) hands[p] = deck.splice(0, 6);

  // первый ход — у кого младший козырь
  let first = 0, minVal = 99;
  room.players.forEach((p, i) => {
    for (const c of hands[p]) {
      if (c.s === trump && RANK_VAL[c.r] < minVal) { minVal = RANK_VAL[c.r]; first = i; }
    }
  });
  const order = [...room.players.slice(first), ...room.players.slice(0, first)];

  room.game = {
    deck, trump, trumpCard, hands, order,
    atkIdx: 0, defIdx: 1,
    table: [], // [{atk, def}]
    phase: 'attack', // attack | defend
    firstRound: true,
    done: [], // кто уже скинул все карты (победители)
    timerStart: Date.now(), timer: null
  };
  room.started = true;
  resetTimer(code);
}

function gameState(code, forPlayer) {
  const room = rooms[code];
  if (!room?.game) return null;
  const g = room.game;
  const alive = g.order.filter(p => !g.done.includes(p));
  const ai = g.atkIdx % alive.length;
  const di = g.defIdx % alive.length;
  const state = {
    code, players: room.players, bet: room.bet,
    trump: g.trump, trumpCard: g.trumpCard,
    deckLeft: g.deck.length, table: g.table,
    phase: g.phase, attacker: alive[ai], defender: alive[di],
    done: g.done, alive, firstRound: g.firstRound,
    timerStart: g.timerStart, hands: {}
  };
  for (const p of room.players) {
    state.hands[p] = p === forPlayer ? g.hands[p] : (g.hands[p]?.length ?? 0);
  }
  return state;
}

function pushState(code) {
  const room = rooms[code];
  if (!room) return;
  for (const p of room.players) {
    const sid = userSock[p];
    if (sid) io.to(sid).emit('state', gameState(code, p));
  }
}

function resetTimer(code) {
  const room = rooms[code];
  if (!room?.game) return;
  const g = room.game;
  if (g.timer) clearTimeout(g.timer);
  g.timerStart = Date.now();
  g.timer = setTimeout(() => autoPass(code), 45000);
}

function autoPass(code) {
  const room = rooms[code];
  if (!room?.game) return;
  const g = room.game;
  const alive = g.order.filter(p => !g.done.includes(p));
  const defender = alive[g.defIdx % alive.length];
  // защитник берёт все карты
  const all = g.table.flatMap(t => t.def ? [t.atk, t.def] : [t.atk]);
  g.hands[defender].push(...all);
  g.table = [];
  g.firstRound = false;
  nextTurn(code, true);
  pushState(code);
}

function fillHands(code) {
  const g = rooms[code].game;
  const alive = g.order.filter(p => !g.done.includes(p));
  const ai = g.atkIdx % alive.length;
  const seq = [...alive.slice(ai), ...alive.slice(0, ai)];
  for (const p of seq) {
    while (g.hands[p].length < 6 && g.deck.length > 0) g.hands[p].push(g.deck.pop());
  }
}

function checkDone(code) {
  const g = rooms[code].game;
  if (g.deck.length > 0) return;
  const alive = g.order.filter(p => !g.done.includes(p));
  for (const p of alive) {
    if (g.hands[p].length === 0 && !g.done.includes(p)) g.done.push(p);
  }
  const remaining = g.order.filter(p => !g.done.includes(p));
  if (remaining.length <= 1) {
    if (g.timer) clearTimeout(g.timer);
    const loser = remaining[0] || null;
    endGame(code, loser);
  }
}

function endGame(code, loser) {
  const room = rooms[code];
  if (!room) return;
  room.game.phase = 'over';
  const bet = room.bet;
  const winners = room.players.filter(p => p !== loser);
  for (const p of room.players) {
    const u = db.users[p]; if (!u) continue;
    u.games++;
    if (p === loser) u.balance = Math.max(0, u.balance - bet * winners.length);
    else { u.wins++; u.balance += bet * (room.players.length - 1); }
  }
  save();
  io.to(code).emit('gameover', { loser, winners, bet });
  setTimeout(() => { delete rooms[code]; }, 30000);
}

function nextTurn(code, defTook) {
  const g = rooms[code].game;
  const alive = g.order.filter(p => !g.done.includes(p));
  const len = alive.length;
  if (defTook) {
    // атакующий остаётся, защитник пропускает ход
    g.atkIdx = (g.atkIdx + 1) % len;
    g.defIdx = (g.atkIdx + 1) % len;
  } else {
    g.atkIdx = g.defIdx % len;
    g.defIdx = (g.atkIdx + 1) % len;
  }
  g.phase = 'attack';
  g.firstRound = false;
  fillHands(code);
  checkDone(code);
  resetTimer(code);
}

function leaveGame(code, username) {
  const room = rooms[code];
  if (!room) return;
  if (!room.started) {
    room.players = room.players.filter(p => p !== username);
    if (room.players.length === 0) { delete rooms[code]; return; }
    if (room.host === username) room.host = room.players[0];
    io.to(code).emit('roomUpdate', room);
    return;
  }
  // игра идёт — проигрыш
  if (room.game && room.game.phase !== 'over') {
    if (room.game.timer) clearTimeout(room.game.timer);
    endGame(code, username);
  }
}

// ─── SOCKET ──────────────────────────────────────────────────
io.on('connection', socket => {

  socket.on('login', username => {
    online[socket.id] = username;
    userSock[username] = socket.id;
  });

  // ── ROOM ──
  socket.on('createRoom', ({ username, maxPlayers, bet }) => {
    const u = db.users[username];
    if (!u || u.balance < bet) return socket.emit('err', 'Недостаточно средств');
    const code = genCode();
    rooms[code] = { code, host: username, maxPlayers, bet, players: [username], started: false, game: null };
    socket.join(code);
    socket.emit('roomCreated', rooms[code]);
  });

  socket.on('joinRoom', ({ username, code }) => {
    code = code.toUpperCase();
    const room = rooms[code];
    if (!room) return socket.emit('err', 'Комната не найдена');
    if (room.started) return socket.emit('err', 'Игра уже началась');
    if (room.players.length >= room.maxPlayers) return socket.emit('err', 'Комната заполнена');
    if (room.players.includes(username)) { socket.join(code); socket.emit('roomCreated', room); return; }
    const u = db.users[username];
    if (!u || u.balance < room.bet) return socket.emit('err', 'Недостаточно средств');
    room.players.push(username);
    socket.join(code);
    io.to(code).emit('roomUpdate', room);
    if (room.players.length === room.maxPlayers) {
      startGame(code);
      pushState(code);
    }
  });

  socket.on('startGame', ({ username, code }) => {
    const room = rooms[code];
    if (!room || room.host !== username) return;
    if (room.players.length < 2) return socket.emit('err', 'Нужно минимум 2 игрока');
    startGame(code);
    pushState(code);
  });

  socket.on('leaveRoom', ({ username, code }) => {
    leaveGame(code, username);
    socket.leave(code);
    socket.emit('leftRoom');
  });

  // ── GAME ACTIONS ──
  socket.on('attack', ({ username, code, cards }) => {
    const room = rooms[code]; if (!room?.game) return;
    const g = room.game;
    const alive = g.order.filter(p => !g.done.includes(p));
    if (alive[g.atkIdx % alive.length] !== username) return socket.emit('err', 'Не ваш ход');
    if (g.phase !== 'attack') return socket.emit('err', 'Сейчас фаза защиты');
    if (!cards.length) return socket.emit('err', 'Выберите карты');
    // все карты одного достоинства
    if (!cards.every(c => c.r === cards[0].r)) return socket.emit('err', 'Все карты должны быть одного достоинства');
    // если стол не пустой — достоинство должно совпадать
    if (g.table.length > 0) {
      const tableRanks = new Set(g.table.flatMap(t => t.def ? [t.atk.r, t.def.r] : [t.atk.r]));
      if (!tableRanks.has(cards[0].r)) return socket.emit('err', 'Такого достоинства нет на столе');
    }
    const defender = alive[g.defIdx % alive.length];
    const defCards = g.hands[defender].length;
    const uncovered = g.table.filter(t => !t.def).length;
    const canAdd = Math.min(6 - g.table.length, defCards - uncovered);
    if (cards.length > canAdd) return socket.emit('err', 'Слишком много карт');
    // убрать из руки
    for (const c of cards) {
      const i = g.hands[username].findIndex(x => cardEq(x, c));
      if (i === -1) return socket.emit('err', 'Карта не найдена в руке');
      g.hands[username].splice(i, 1);
    }
    for (const c of cards) g.table.push({ atk: c, def: null });
    g.phase = 'defend';
    resetTimer(code);
    pushState(code);
  });

  socket.on('defend', ({ username, code, atkIdx, card }) => {
    const room = rooms[code]; if (!room?.game) return;
    const g = room.game;
    const alive = g.order.filter(p => !g.done.includes(p));
    if (alive[g.defIdx % alive.length] !== username) return socket.emit('err', 'Не ваш ход');
    if (g.phase !== 'defend') return socket.emit('err', 'Сейчас не фаза защиты');
    const slot = g.table[atkIdx];
    if (!slot || slot.def) return socket.emit('err', 'Неверный слот');
    if (!beats(slot.atk, card, g.trump)) return socket.emit('err', 'Карта не бьёт');
    const i = g.hands[username].findIndex(x => cardEq(x, card));
    if (i === -1) return socket.emit('err', 'Карта не найдена');
    g.hands[username].splice(i, 1);
    slot.def = card;
    // если все отбиты — переходим обратно к атаке
    if (g.table.every(t => t.def)) { g.phase = 'attack'; resetTimer(code); }
    pushState(code);
  });

  socket.on('transfer', ({ username, code, cards }) => {
    const room = rooms[code]; if (!room?.game) return;
    const g = room.game;
    if (g.firstRound) return socket.emit('err', 'В первом раунде нельзя переводить');
    const alive = g.order.filter(p => !g.done.includes(p));
    if (alive[g.defIdx % alive.length] !== username) return socket.emit('err', 'Не ваш ход');
    if (g.phase !== 'defend') return socket.emit('err', 'Нельзя переводить');
    if (g.table.some(t => t.def)) return socket.emit('err', 'Уже отбивали — нельзя перевести');
    if (!cards.length) return socket.emit('err', 'Выберите карты');
    const needRank = g.table[0].atk.r;
    if (!cards.every(c => c.r === needRank)) return socket.emit('err', 'Карты должны быть того же достоинства');
    const nextDefIdx = (g.defIdx + 1) % alive.length;
    const nextDef = alive[nextDefIdx];
    if (g.table.length + cards.length > g.hands[nextDef].length) return socket.emit('err', 'У следующего не хватает карт');
    for (const c of cards) {
      const i = g.hands[username].findIndex(x => cardEq(x, c));
      if (i === -1) return socket.emit('err', 'Карта не найдена');
      g.hands[username].splice(i, 1);
    }
    for (const c of cards) g.table.push({ atk: c, def: null });
    g.defIdx = nextDefIdx;
    resetTimer(code);
    pushState(code);
  });

  socket.on('throw', ({ username, code, cards }) => {
    const room = rooms[code]; if (!room?.game) return;
    const g = room.game;
    const alive = g.order.filter(p => !g.done.includes(p));
    const defender = alive[g.defIdx % alive.length];
    if (defender === username) return socket.emit('err', 'Защитник не может подкидывать');
    if (g.phase !== 'defend') return socket.emit('err', 'Сейчас не фаза защиты');
    if (!cards.length) return socket.emit('err', 'Выберите карты');
    const tableRanks = new Set(g.table.flatMap(t => t.def ? [t.atk.r, t.def.r] : [t.atk.r]));
    for (const c of cards) if (!tableRanks.has(c.r)) return socket.emit('err', `${c.r} нет на столе`);
    const uncovered = g.table.filter(t => !t.def).length;
    const canAdd = Math.min(6 - g.table.length, g.hands[defender].length - uncovered);
    if (cards.length > canAdd) return socket.emit('err', 'Слишком много карт');
    for (const c of cards) {
      const i = g.hands[username].findIndex(x => cardEq(x, c));
      if (i === -1) return socket.emit('err', 'Карта не найдена');
      g.hands[username].splice(i, 1);
    }
    for (const c of cards) g.table.push({ atk: c, def: null });
    pushState(code);
  });

  socket.on('take', ({ username, code }) => {
    const room = rooms[code]; if (!room?.game) return;
    const g = room.game;
    const alive = g.order.filter(p => !g.done.includes(p));
    if (alive[g.defIdx % alive.length] !== username) return socket.emit('err', 'Не ваш ход');
    const all = g.table.flatMap(t => t.def ? [t.atk, t.def] : [t.atk]);
    g.hands[username].push(...all);
    g.table = [];
    nextTurn(code, true);
    pushState(code);
  });

  socket.on('endAttack', ({ username, code }) => {
    const room = rooms[code]; if (!room?.game) return;
    const g = room.game;
    const alive = g.order.filter(p => !g.done.includes(p));
    if (alive[g.atkIdx % alive.length] !== username) return socket.emit('err', 'Не ваш ход');
    if (!g.table.every(t => t.def)) return socket.emit('err', 'Не все карты отбиты');
    g.table.forEach(t => { /* сброс в битые */ });
    g.table = [];
    nextTurn(code, false);
    pushState(code);
  });

  // ── SOCIAL ──
  socket.on('searchUser', ({ query, me }) => {
    const res = Object.values(db.users)
      .filter(u => u.username !== me && u.username.toLowerCase().includes(query.toLowerCase()))
      .slice(0, 10)
      .map(u => ({ username: u.username, emoji: u.emoji, photo: u.photo }));
    socket.emit('searchResult', res);
  });

  socket.on('addFriend', ({ from, to }) => {
    const target = db.users[to]; if (!target) return;
    const me = db.users[from]; if (!me) return;
    if ((me.friends || []).includes(to)) return socket.emit('err', 'Уже в друзьях');
    if (!target.requests) target.requests = [];
    if (target.requests.includes(from)) return;
    target.requests.push(from);
    const notif = { id: Date.now(), type: 'friendReq', from, time: Date.now() };
    if (!target.notifs) target.notifs = [];
    target.notifs.push(notif);
    save();
    const sid = userSock[to];
    if (sid) io.to(sid).emit('notif', notif);
    socket.emit('ok', 'Заявка отправлена');
  });

  socket.on('acceptFriend', ({ me, from }) => {
    const u = db.users[me], f = db.users[from]; if (!u || !f) return;
    if (!u.friends) u.friends = []; if (!f.friends) f.friends = [];
    if (!u.friends.includes(from)) u.friends.push(from);
    if (!f.friends.includes(me)) f.friends.push(me);
    u.requests = (u.requests || []).filter(r => r !== from);
    u.notifs = (u.notifs || []).filter(n => !(n.type === 'friendReq' && n.from === from));
    save();
    socket.emit('friendsUpd', u.friends);
    const sid = userSock[from];
    if (sid) io.to(sid).emit('friendAccepted', { by: me });
  });

  socket.on('declineFriend', ({ me, from }) => {
    const u = db.users[me]; if (!u) return;
    u.requests = (u.requests || []).filter(r => r !== from);
    u.notifs = (u.notifs || []).filter(n => !(n.type === 'friendReq' && n.from === from));
    save();
    socket.emit('notifsUpd', u.notifs);
  });

  socket.on('removeFriend', ({ me, friend }) => {
    const u = db.users[me], f = db.users[friend];
    if (u) u.friends = (u.friends || []).filter(x => x !== friend);
    if (f) f.friends = (f.friends || []).filter(x => x !== me);
    save();
    socket.emit('friendsUpd', u?.friends || []);
  });

  socket.on('getFriends', ({ username }) => {
    const u = db.users[username]; if (!u) return;
    const list = (u.friends || []).map(fn => {
      const f = db.users[fn];
      return f ? { username: f.username, emoji: f.emoji, photo: f.photo, online: !!userSock[fn] } : null;
    }).filter(Boolean);
    socket.emit('friendsList', { list, requests: u.requests || [] });
  });

  socket.on('inviteToRoom', ({ from, to, code }) => {
    const sid = userSock[to]; if (!sid) return socket.emit('err', 'Игрок не онлайн');
    const notif = { id: Date.now(), type: 'roomInvite', from, code, time: Date.now() };
    const target = db.users[to];
    if (target) { if (!target.notifs) target.notifs = []; target.notifs.push(notif); save(); }
    io.to(sid).emit('notif', notif);
    socket.emit('ok', 'Приглашение отправлено');
  });

  socket.on('dismissNotif', ({ username, id }) => {
    const u = db.users[username]; if (!u) return;
    u.notifs = (u.notifs || []).filter(n => n.id !== id); save();
  });

  // ── CHAT ──
  socket.on('getChat', ({ a, b }) => {
    const id = [a, b].sort().join(':');
    socket.emit('chatHistory', { id, msgs: db.chats[id] || [] });
  });

  socket.on('sendMsg', ({ from, to, text, img }) => {
    const id = [from, to].sort().join(':');
    if (!db.chats[id]) db.chats[id] = [];
    const msg = { id: Date.now(), from, text: text || '', img: img || null, time: Date.now() };
    db.chats[id].push(msg);
    if (db.chats[id].length > 200) db.chats[id] = db.chats[id].slice(-200);
    save();
    socket.emit('msg', msg);
    const sid = userSock[to]; if (sid) io.to(sid).emit('msg', msg);
  });

  socket.on('createGroup', ({ creator, name, members }) => {
    if (members.length > 11) return socket.emit('err', 'Максимум 12 участников');
    const id = 'g_' + Date.now();
    const all = [creator, ...members.filter(m => m !== creator)];
    db.groups[id] = { id, name, creator, members: all, msgs: [] };
    save();
    for (const m of all) { const sid = userSock[m]; if (sid) io.to(sid).emit('groupCreated', db.groups[id]); }
  });

  socket.on('getGroups', ({ username }) => {
    socket.emit('groupsList', Object.values(db.groups).filter(g => g.members.includes(username)));
  });

  socket.on('groupMsg', ({ groupId, from, text, img }) => {
    const g = db.groups[groupId]; if (!g) return;
    const msg = { id: Date.now(), from, text: text || '', img: img || null, time: Date.now() };
    g.msgs.push(msg);
    if (g.msgs.length > 200) g.msgs = g.msgs.slice(-200);
    save();
    for (const m of g.members) { const sid = userSock[m]; if (sid) io.to(sid).emit('groupMsg', { groupId, msg }); }
  });

  socket.on('getGroupMsgs', ({ groupId }) => {
    const g = db.groups[groupId];
    socket.emit('groupHistory', { groupId, msgs: g ? g.msgs : [] });
  });

  // ── WHEEL ──
  socket.on('spin', ({ username }) => {
    const u = db.users[username]; if (!u) return;
    const now = Date.now();
    if (now - (u.lastSpin || 0) < 86400000) {
      const h = Math.ceil((86400000 - (now - u.lastSpin)) / 3600000);
      return socket.emit('spinResult', { ok: false, err: `Следующий спин через ${h} ч.` });
    }
    const prizes = [
      { label: 'Ничего', type: 'nothing', prob: 30 },
      { label: '+100₽', type: 'flat', val: 100, prob: 25 },
      { label: '+300₽', type: 'flat', val: 300, prob: 18 },
      { label: 'x1.5', type: 'mult', val: 1.5, prob: 12 },
      { label: 'x2', type: 'mult', val: 2, prob: 8 },
      { label: '+1000₽', type: 'flat', val: 1000, prob: 4 },
      { label: 'x3', type: 'mult', val: 3, prob: 2 },
      { label: '🎰 ДЖЕКПОТ x5', type: 'mult', val: 5, prob: 1 },
    ];
    const total = prizes.reduce((s, p) => s + p.prob, 0);
    let r = Math.random() * total, prize = prizes[0];
    for (const p of prizes) { r -= p.prob; if (r <= 0) { prize = p; break; } }
    u.lastSpin = now;
    if (prize.type === 'flat') u.balance += prize.val;
    if (prize.type === 'mult') u.balance = Math.floor(u.balance * prize.val);
    save();
    socket.emit('spinResult', { ok: true, prize, balance: u.balance });
  });

  // ── SHOP ──
  socket.on('buyBoost', ({ username, boost }) => {
    const u = db.users[username]; if (!u) return;
    const prices = { skip: 100, view: 150, shield: 200 };
    const price = prices[boost];
    if (!price) return socket.emit('err', 'Неизвестный буст');
    if (u.balance < price) return socket.emit('err', 'Недостаточно средств');
    u.balance -= price;
    u.boosts[boost] = (u.boosts[boost] || 0) + 1;
    save();
    socket.emit('boostBought', { boost, balance: u.balance, boosts: u.boosts });
  });

  // ── OWNER CONSOLE ──
  socket.on('cmd', ({ username, cmd }) => {
    if (username !== 'MrDarvi') return socket.emit('cmdOut', '❌ Нет доступа');
    const parts = cmd.trim().split(' ');
    const c = parts[0];
    if (c === '/lspl') {
      const names = Object.values(online);
      socket.emit('cmdOut', `Онлайн (${names.length}): ${names.join(', ')}\nВсего: ${Object.keys(db.users).length}`);
    } else if (c === '/ban') {
      const n = parts[1]; if (!n || !db.users[n]) return socket.emit('cmdOut', '❌ Не найден');
      if (n === 'MrDarvi') return socket.emit('cmdOut', '❌ Нельзя');
      db.users[n].banned = true; db.users[n].banUntil = null; save();
      const sid = userSock[n]; if (sid) io.to(sid).emit('kicked', 'Вы заблокированы');
      socket.emit('cmdOut', `✅ ${n} заблокирован`);
    } else if (c === '/bantime') {
      const n = parts[1], h = parseFloat(parts[2]);
      if (!n || !db.users[n] || isNaN(h)) return socket.emit('cmdOut', '❌ /bantime ник часы');
      db.users[n].banned = true; db.users[n].banUntil = Date.now() + h * 3600000; save();
      const sid = userSock[n]; if (sid) io.to(sid).emit('kicked', `Бан на ${h} ч.`);
      socket.emit('cmdOut', `✅ ${n} забанен на ${h} ч.`);
    } else if (c === '/unban') {
      const n = parts[1]; if (!n || !db.users[n]) return socket.emit('cmdOut', '❌ Не найден');
      db.users[n].banned = false; db.users[n].banUntil = null; save();
      socket.emit('cmdOut', `✅ ${n} разблокирован`);
    } else if (c === '/give') {
      if (parts[1] === 'all') {
        const s = parseInt(parts[2]); if (isNaN(s)) return socket.emit('cmdOut', '❌ /give all сумма');
        for (const u of Object.values(db.users)) u.balance += s; save();
        io.emit('balanceAdd', { amount: s });
        socket.emit('cmdOut', `✅ Всем +${s}₽`);
      } else {
        const n = parts[1], s = parseInt(parts[2]);
        if (!n || !db.users[n] || isNaN(s)) return socket.emit('cmdOut', '❌ /give ник сумма');
        db.users[n].balance += s; save();
        const sid = userSock[n]; if (sid) io.to(sid).emit('balanceAdd', { amount: s });
        socket.emit('cmdOut', `✅ ${n} +${s}₽ (итого ${db.users[n].balance}₽)`);
      }
    } else if (c === '/bc') {
      const msg = parts.slice(1).join(' '); if (!msg) return socket.emit('cmdOut', '❌ /bc текст');
      io.emit('broadcast', msg);
      socket.emit('cmdOut', `✅ Отправлено: ${msg}`);
    } else {
      socket.emit('cmdOut', 'Команды:\n/lspl\n/ban ник\n/bantime ник часы\n/unban ник\n/give all сумма\n/give ник сумма\n/bc текст');
    }
  });

  socket.on('disconnect', () => {
    const username = online[socket.id];
    if (!username) return;
    delete online[socket.id];
    delete userSock[username];
    for (const code in rooms) {
      if (rooms[code].players.includes(username)) leaveGame(code, username);
    }
  });
});

const PORT = process.env.PORT || 80;
server.listen(PORT, '0.0.0.0', () => console.log(`Server running on port ${PORT}`));
